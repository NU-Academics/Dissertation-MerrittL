| Model                                |   AUC |   Accuracy |   Precision |   Recall |    F1 |
|:-------------------------------------|------:|-----------:|------------:|---------:|------:|
| RQ1 Forensic XGB (without file_size) | 0.639 |      0.599 |       0.645 |    0.44  | 0.523 |
| RQ1A Forensic XGB (with file_size)   | 0.677 |      0.637 |       0.757 |    0.403 | 0.526 |