| Model               | Real-only deciles   |   n_deciles |   n_images |   n_real |   n_fake | % of test   |
|:--------------------|:--------------------|------------:|-----------:|---------:|---------:|:------------|
| RQ1 Forensic XGB    | None                |           0 |          0 |        0 |        0 | 0.00%       |
| RQ2 BoVW+KMeans XGB | None                |           0 |          0 |        0 |        0 | 0.00%       |
| RQ3 BoVW Raw XGB    | None                |           0 |          0 |        0 |        0 | 0.00%       |
| RQ3 BoVW PCA XGB    | None                |           0 |          0 |        0 |        0 | 0.00%       |
| RQ4 CNN             | None                |           0 |          0 |        0 |        0 | 0.00%       |
| RQ5 Ensemble XGB    | None                |           0 |          0 |        0 |        0 | 0.00%       |